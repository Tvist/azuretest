This sample script creates a Service Bus namespace and queue, along with a Function App.

There are quite a few components that aren't available in the Azure CLI. The complete examples from chapter 21 fill in the gaps with the use of the Azure portal. As such, this is not a complete example script that provides a functional end result at the end of the script.