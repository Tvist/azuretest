Very basic Azure Resource Manager template that creates an Availability Set and deploys multiple VMs in to it.

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Ffouldsy%2Fazure-samples%2Fmaster%2F7%2Favailability-set%2Favailabilityset-template.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>
<a href="http://armviz.io/#/?load=https%3A%2F%2Fraw.githubusercontent.com%2Ffouldsy%2Fazure-samples%2Fmaster%2F7%2Favailability-set%2Favailabilityset-template.json" target="_blank">
    <img src="http://armviz.io/visualizebutton.png"/>
</a>
