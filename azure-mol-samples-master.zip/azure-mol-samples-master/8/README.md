This sample script creates an Azure load balancer, pools, load balancer rules, and NAT rules.

Two VMs are then created and attached to the back-end pool. The Azure Custom Script Extension is used to install NGINX and a sample HTML page for each node.